package com.example.socialnetwork.data

data class Post(
    val id : Int,
    val post_title : String,
    val post_description: String,
    val etat : Int
)

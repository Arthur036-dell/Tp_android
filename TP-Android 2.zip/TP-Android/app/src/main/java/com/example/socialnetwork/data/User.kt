package com.example.socialnetwork.data

data class User(
    val id: Int,
    val name: String,
    val password: String,
    val etat : Int
)
